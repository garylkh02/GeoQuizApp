package com.example.geoquiz

import androidx.lifecycle.ViewModel

private const val TAG = "ResultViewModel"

class ResultViewModel : ViewModel() {
}