package com.example.geoquiz

import androidx.lifecycle.ViewModel

private const val TAG = "CheatViewModel"

class CheatViewModel : ViewModel() {
    var isCheater = false
    var cheatToken = 3

    fun resetCheat(){
        cheatToken = 3
    }
}

