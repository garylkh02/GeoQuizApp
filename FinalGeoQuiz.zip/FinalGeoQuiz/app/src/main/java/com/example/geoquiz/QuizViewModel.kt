package com.example.geoquiz

import androidx.lifecycle.ViewModel

private const val TAG = "QuizViewModel"

class QuizViewModel : ViewModel() {
    private val questionBank = listOf(
        Question(R.string.question1, true),
        Question(R.string.question2, true),
        Question(R.string.question3, true),
        Question(R.string.question4, false),
        Question(R.string.question5, false),
        Question(R.string.question6, true),
        Question(R.string.question7, true),
        Question(R.string.question8, false),
        Question(R.string.question9, false),
        Question(R.string.question10, false)

    )

    private var randomizedQuestionBank = questionBank.shuffled()

    var currentIndex = 0
    var disablenext = false
    var disableprev = false
    var correctNum = 0
    var totalQuesAns = 0



    val currentQuestionAnswer: Boolean
        get() = randomizedQuestionBank[currentIndex].answer
    val currentQuestionText: Int
        get() = randomizedQuestionBank[currentIndex].textResId
    val iscurrentQuestionAnswered: Boolean
        get() = randomizedQuestionBank[currentIndex].isAnswered
    val questionBankSize: Int
        get() = randomizedQuestionBank.size

    fun nextQuestion() {
        currentIndex = (currentIndex + 1)
    }

    fun prevQuestion(){
        currentIndex = (currentIndex - 1)

    }

    fun checkButtonAvailability(){
        disablenext = currentIndex == randomizedQuestionBank.size - 1
        disableprev = currentIndex == 0
    }
    fun answeredQuestion(){
        randomizedQuestionBank[currentIndex].isAnswered = true
    }

    fun resetQuestion(){
        var num = 0
        while(num < randomizedQuestionBank.size){
            randomizedQuestionBank[num].isAnswered = false
            num++
        }
        currentIndex = 0
        correctNum = 0
        totalQuesAns = 0
        randomizedQuestionBank = questionBank.shuffled()
    }

    fun isAllAnswered():Boolean{
        var num = 0
        var check = true
        while(num < randomizedQuestionBank.size){
            if(!randomizedQuestionBank[num].isAnswered) {
                check = false
            }
            num++
        }
        return check
    }

    fun totalScore():Double{
        return correctNum.toDouble()/randomizedQuestionBank.size * 100
    }

}