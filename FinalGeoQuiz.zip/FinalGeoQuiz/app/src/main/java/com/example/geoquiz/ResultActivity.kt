package com.example.geoquiz

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

private const val TAG = "ResultActivity"
const val EXTRA_TOTAL_QUESTIONS = "extra_total_questions"
const val EXTRA_TOTAL_SCORE = "extra_total_score"
const val EXTRA_TOTAL_CHEATS = "extra_total_cheats"


class ResultActivity : AppCompatActivity() {
    private lateinit var totalQuestionsAnswered: TextView
    private lateinit var totalScores: TextView
    private lateinit var totalCheats: TextView
    private lateinit var results: TextView
    private lateinit var backButton: Button

    private val resultViewModel: ResultViewModel by lazy {
        ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(ResultViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        results = findViewById(R.id.result)
        totalQuestionsAnswered = findViewById(R.id.totalQuestionAnswered)
        totalScores = findViewById(R.id.totalScore)
        totalCheats = findViewById(R.id.cheatTimes)

        val totalQuestions = intent.getIntExtra(EXTRA_TOTAL_QUESTIONS, 0)
        val totalScore = intent.getDoubleExtra(EXTRA_TOTAL_SCORE, 0.0)
        val totalCheat = intent.getIntExtra(EXTRA_TOTAL_CHEATS, 0)

        totalQuestionsAnswered.text = getString(R.string.totalQuestionAnswered, totalQuestions)
        totalScores.text = getString(R.string.totalScore, totalScore)
        totalCheats.text = getString(R.string.cheatTimes, totalCheat)

        backButton = findViewById(R.id.back_button)
        backButton.setOnClickListener {
            finish() // Close the ResultActivity and return to the previous activity (MainActivity)
        }
    }

    companion object {
        fun newIntent(packageContext: Context, totalQuesAns: Int, totalScore: Double, totalCheat: Int): Intent {
            return Intent(packageContext, ResultActivity::class.java).apply {
                putExtra(EXTRA_TOTAL_QUESTIONS, totalQuesAns)
                putExtra(EXTRA_TOTAL_SCORE, totalScore)
                putExtra(EXTRA_TOTAL_CHEATS, totalCheat)
            }
        }
    }
}